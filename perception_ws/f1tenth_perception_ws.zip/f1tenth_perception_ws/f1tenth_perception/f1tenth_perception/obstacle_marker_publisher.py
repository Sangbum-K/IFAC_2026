#!/usr/bin/env python3
"""
obstacle_marker_publisher
- /perception/obstacles (f1tenth_perception_msgs/ObstacleArray) 구독
- RViz 시각화를 위해 visualization_msgs/MarkerArray로 변환하여 발행
  - 위치: 구(SPHERE) 마커, 정적=파랑 / 동적=빨강
  - 속도: 화살표(ARROW) 마커 (동적 장애물만, 속도 벡터 방향/크기로 표시)
  - 텍스트: id + speed 라벨 (선택)
"""
import rclpy
from rclpy.node import Node
from rclpy.duration import Duration

from geometry_msgs.msg import Point
from visualization_msgs.msg import Marker, MarkerArray

from f1tenth_perception_msgs.msg import ObstacleArray


class ObstacleMarkerPublisher(Node):

    def __init__(self):
        super().__init__('obstacle_marker_publisher')

        self.declare_parameter('obstacle_topic', '/perception/obstacles')
        self.declare_parameter('marker_topic', '/perception/obstacle_markers')
        self.declare_parameter('marker_lifetime_sec', 0.3)
        self.declare_parameter('sphere_diameter', 0.3)     # [m] 장애물 반경과 별개로 최소 시인성 확보용 기본 지름
        self.declare_parameter('arrow_speed_scale', 1.0)   # 속도(m/s) -> 화살표 길이(m) 배율
        self.declare_parameter('show_labels', True)

        p = self.get_parameter
        obstacle_topic = p('obstacle_topic').value
        marker_topic = p('marker_topic').value
        self.lifetime_sec = p('marker_lifetime_sec').value
        self.sphere_diameter = p('sphere_diameter').value
        self.arrow_speed_scale = p('arrow_speed_scale').value
        self.show_labels = p('show_labels').value

        self.sub = self.create_subscription(
            ObstacleArray, obstacle_topic, self.on_obstacles, 10
        )
        self.pub = self.create_publisher(MarkerArray, marker_topic, 10)

        self.get_logger().info(
            f'obstacle_marker_publisher started: {obstacle_topic} -> {marker_topic}'
        )

    def on_obstacles(self, msg: ObstacleArray):
        marker_array = MarkerArray()
        lifetime = Duration(seconds=self.lifetime_sec).to_msg()

        for obs in msg.obstacles:
            # 정적=파랑, 동적=빨강 (confidence가 낮으면 반투명하게 표시해 신뢰도 표현)
            if obs.is_dynamic:
                color = (1.0, 0.15, 0.15)
            else:
                color = (0.2, 0.5, 1.0)
            alpha = max(0.3, min(1.0, obs.confidence))

            # ---- ① 위치: 구(SPHERE) ----
            sphere = Marker()
            sphere.header = msg.header
            sphere.ns = 'obstacle_position'
            sphere.id = obs.id
            sphere.type = Marker.SPHERE
            sphere.action = Marker.ADD
            sphere.pose.position = Point(
                x=obs.position.x, y=obs.position.y, z=0.0
            )
            sphere.pose.orientation.w = 1.0

            diameter = max(self.sphere_diameter, obs.radius * 2.0)
            sphere.scale.x = diameter
            sphere.scale.y = diameter
            sphere.scale.z = diameter

            sphere.color.r, sphere.color.g, sphere.color.b = color
            sphere.color.a = alpha
            sphere.lifetime = lifetime
            marker_array.markers.append(sphere)

            # ---- ② 속도: 화살표(ARROW) ----
            # 정적 장애물(속도 0)은 화살표 대신 DELETE로 지워서 잔상이 안 남게 처리
            arrow = Marker()
            arrow.header = msg.header
            arrow.ns = 'obstacle_velocity'
            arrow.id = obs.id
            arrow.type = Marker.ARROW
            arrow.lifetime = lifetime

            speed = (obs.velocity.x ** 2 + obs.velocity.y ** 2) ** 0.5
            if obs.is_dynamic and speed > 1e-3:
                arrow.action = Marker.ADD
                start = Point(x=obs.position.x, y=obs.position.y, z=0.05)
                end = Point(
                    x=obs.position.x + obs.velocity.x * self.arrow_speed_scale,
                    y=obs.position.y + obs.velocity.y * self.arrow_speed_scale,
                    z=0.05,
                )
                arrow.points = [start, end]
                arrow.scale.x = 0.06   # shaft diameter
                arrow.scale.y = 0.12   # head diameter
                arrow.scale.z = 0.15   # head length
                arrow.color.r, arrow.color.g, arrow.color.b = (1.0, 0.85, 0.0)
                arrow.color.a = 0.9
            else:
                arrow.action = Marker.DELETE
            marker_array.markers.append(arrow)

            # ---- ③ 텍스트 라벨 (선택) ----
            if self.show_labels:
                label = Marker()
                label.header = msg.header
                label.ns = 'obstacle_label'
                label.id = obs.id
                label.type = Marker.TEXT_VIEW_FACING
                label.action = Marker.ADD
                label.pose.position = Point(
                    x=obs.position.x, y=obs.position.y, z=diameter / 2.0 + 0.15
                )
                label.pose.orientation.w = 1.0
                label.scale.z = 0.18  # 텍스트 높이
                label.color.r, label.color.g, label.color.b = (1.0, 1.0, 1.0)
                label.color.a = 0.9
                label.lifetime = lifetime
                kind = 'DYN' if obs.is_dynamic else 'STA'
                label.text = f'#{obs.id} {kind} {speed:.2f}m/s'
                marker_array.markers.append(label)

        self.pub.publish(marker_array)


def main(args=None):
    rclpy.init(args=args)
    node = ObstacleMarkerPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
