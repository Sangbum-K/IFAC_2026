import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    config = os.path.join(
        get_package_share_directory('f1tenth_perception'),
        'config',
        'obstacle_params.yaml',
    )

    return LaunchDescription([
        Node(
            package='f1tenth_perception',
            executable='obstacle_detector_node',
            name='obstacle_detector_node',
            output='screen',
            parameters=[config],
        ),
        Node(
            package='f1tenth_perception',
            executable='obstacle_marker_publisher',
            name='obstacle_marker_publisher',
            output='screen',
            parameters=[{
                'obstacle_topic': '/perception/obstacles',
                'marker_topic': '/perception/obstacle_markers',
                'marker_lifetime_sec': 0.3,
                'sphere_diameter': 0.3,
                'arrow_speed_scale': 1.0,
                'show_labels': True,
            }],
        ),
    ])
